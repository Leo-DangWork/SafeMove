///*
// * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
// * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
// */
//package dao;
//
///**
// *
// * @author Admin
// */
//public class SurveyDAO {
//    
//}

package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.SurveyRequest;
import utils.DBContext;

public class SurveyDAO {

    /**
     * Chức năng: Thêm mới một yêu cầu khảo sát vào database
     */
    public boolean insertSR(SurveyRequest sr) {
        String sql = "INSERT INTO SurveyRequest (customer_id, pickup_address, destination_address, expected_date, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, sr.getCustomerId());
            ps.setNString(2, sr.getPickupAddress());
            ps.setNString(3, sr.getDestinationAddress());
            ps.setTimestamp(4, sr.getExpectedDate());
            ps.setString(5, "Pending"); // Mặc định là đang chờ

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * Chức năng: Lấy tất cả yêu cầu khảo sát của một khách hàng cụ thể
     */
    public List<SurveyRequest> getSRByCustomer(int customerId) {
        List<SurveyRequest> list = new ArrayList<>();
        String sql = "SELECT * FROM SurveyRequest WHERE customer_id = ? ORDER BY expected_date DESC";
        
        try (Connection conn = DBContext.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, customerId);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(new SurveyRequest(
                    rs.getInt("request_id"),
                    rs.getInt("customer_id"),
                    rs.getNString("pickup_address"),
                    rs.getNString("destination_address"),
                    rs.getTimestamp("expected_date"),
                    rs.getString("status")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}