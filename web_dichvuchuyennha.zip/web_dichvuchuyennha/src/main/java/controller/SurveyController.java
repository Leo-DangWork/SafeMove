package controller;

import dao.SurveyDAO;
import model.SurveyRequest;
import model.User;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Timestamp;

public class SurveyController extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Giả sử User đã login và lưu trong Session
        User user = (User) request.getSession().getAttribute("user");
        
        String pickup = request.getParameter("pickup");
        String destination = request.getParameter("destination");
        String dateStr = request.getParameter("date"); // yyyy-MM-dd'T'HH:mm
        
        SurveyRequest sr = new SurveyRequest();
        sr.setCustomerId(user.getId());
        sr.setPickupAddress(pickup);
        sr.setDestinationAddress(destination);
        sr.setExpectedDate(Timestamp.valueOf(dateStr.replace("T", " ") + ":00"));
        
        SurveyDAO dao = new SurveyDAO();
        if(dao.insertSR(sr)) {
            response.sendRedirect("view-requests.jsp"); // Thành công chuyển trang
        } else {
            request.setAttribute("msg", "Lỗi gửi yêu cầu!");
            request.getRequestDispatcher("survey.jsp").forward(request, response);
        }
    }
}