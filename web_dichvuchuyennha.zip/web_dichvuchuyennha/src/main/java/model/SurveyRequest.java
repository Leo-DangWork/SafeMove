package model;

import java.sql.Timestamp;

public class SurveyRequest {
    private int requestId;
    private int customerId;
    private String pickupAddress;
    private String destinationAddress;
    private Timestamp expectedDate;
    private String status;

    public SurveyRequest() {}

    public SurveyRequest(int requestId, int customerId, String pickupAddress, String destinationAddress, Timestamp expectedDate, String status) {
        this.requestId = requestId;
        this.customerId = customerId;
        this.pickupAddress = pickupAddress;
        this.destinationAddress = destinationAddress;
        this.expectedDate = expectedDate;
        this.status = status;
    }

    // Getters and Setters
    public int getRequestId() { return requestId; }
    public void setRequestId(int requestId) { this.requestId = requestId; }
    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }
    public String getPickupAddress() { return pickupAddress; }
    public void setPickupAddress(String pickupAddress) { this.pickupAddress = pickupAddress; }
    public String getDestinationAddress() { return destinationAddress; }
    public void setDestinationAddress(String destinationAddress) { this.destinationAddress = destinationAddress; }
    public Timestamp getExpectedDate() { return expectedDate; }
    public void setExpectedDate(Timestamp expectedDate) { this.expectedDate = expectedDate; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}