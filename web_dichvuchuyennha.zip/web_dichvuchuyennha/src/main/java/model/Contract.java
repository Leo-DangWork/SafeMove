package model;

import java.sql.Timestamp;

public class Contract {
    private int contractId;
    private int customerId;
    private String pickupAddress;
    private String destinationAddress;
    private Timestamp moveStart;
    private Timestamp moveEnd;
    private int numWorkers;
    private int numVehicles;
    private double deposit;
    private double totalPrice;
    private String status;

    // Constructor, Getters and Setters tương tự SurveyRequest
}