/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.web_dichvuchuyennha;

/**
 *
 * @author Admin
 */
public class Web_dichvuchuyennha {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
